
  # One-Page Scrolling Presentation

  This is a code bundle for One-Page Scrolling Presentation. The original project is available at https://www.figma.com/design/CN9oytpA0anMhw1s2gumRA/One-Page-Scrolling-Presentation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  